
#ifndef __DT_BINDINGS_CLOCK_R8A7743_CPG_MSSR_H__
#define __DT_BINDINGS_CLOCK_R8A7743_CPG_MSSR_H__

#include <dt-bindings/clock/renesas-cpg-mssr.h>


#define R8A7743_CLK_Z		0
#define R8A7743_CLK_ZG		1
#define R8A7743_CLK_ZTR		2
#define R8A7743_CLK_ZTRD2	3
#define R8A7743_CLK_ZT		4
#define R8A7743_CLK_ZX		5
#define R8A7743_CLK_ZS		6
#define R8A7743_CLK_HP		7
#define R8A7743_CLK_B		9
#define R8A7743_CLK_LB		10
#define R8A7743_CLK_P		11
#define R8A7743_CLK_CL		12
#define R8A7743_CLK_M2		13
#define R8A7743_CLK_ZB3		15
#define R8A7743_CLK_ZB3D2	16
#define R8A7743_CLK_DDR		17
#define R8A7743_CLK_SDH		18
#define R8A7743_CLK_SD0		19
#define R8A7743_CLK_SD2		20
#define R8A7743_CLK_SD3		21
#define R8A7743_CLK_MMC0	22
#define R8A7743_CLK_MP		23
#define R8A7743_CLK_QSPI	26
#define R8A7743_CLK_CP		27
#define R8A7743_CLK_RCAN	28
#define R8A7743_CLK_R		29
#define R8A7743_CLK_OSC		30

#endif 
